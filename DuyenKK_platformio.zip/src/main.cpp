#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED config
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- User config - EDIT THESE ---
const char* WIFI_SSID = "YOUR_SSID";
const char* WIFI_PASS = "YOUR_PASS";
const char* OPENWEATHER_API_KEY = "YOUR_OPENWEATHER_KEY"; // đăng ký ở OpenWeatherMap

// Sample endpoints (you can replace with your preferred APIs)
const char* XSMB_API = "https://api-xsmb.cyclic.app/api/v1"; // sample public endpoint
const char* VNEXPRESS_RSS = "https://vnexpress.net/rss/tin-moi-nhat.rss"; // top news

// Buttons (change to your wiring)
const int BTN_UP = 0;     // GPIO0 (example)
const int BTN_SELECT = 1; // GPIO1 (example) - change as appropriate

// Simple city list (tên theo OpenWeatherMap: City,COUNTRY)
const char* cities[] = {"Hanoi,VN","Ho Chi Minh,VN","Da Nang,VN","Can Tho,VN","Hai Phong,VN"};
const int CITY_COUNT = sizeof(cities)/sizeof(cities[0]);
int cityIndex = 0;

// Menu states
enum ScreenMode {MODE_HOME, MODE_WEATHER, MODE_XSMB, MODE_NEWS};
ScreenMode mode = MODE_HOME;

void connectWiFi(){
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("Connecting to WiFi...");
  display.display();

  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30){
    delay(500);
    display.print(".");
    display.display();
    tries++;
  }

  if (WiFi.status() == WL_CONNECTED){
    display.println();
    display.println("WiFi connected");
    display.display();
  } else {
    display.println();
    display.println("WiFi failed");
    display.display();
  }
}

void setup(){
  Serial.begin(115200);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_SELECT, INPUT_PULLUP);

  // Init display
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)){
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // Show title
  display.setCursor(0,0);
  display.setTextSize(2);
  display.println("DuyenKK");
  display.setTextSize(1);
  display.println("Firmware demo");
  display.display();
  delay(1200);

  connectWiFi();
}

void renderScreen(){
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0,0);
  switch(mode){
    case MODE_HOME:
      display.setTextSize(2);
      display.println("DuyenKK");
      display.setTextSize(1);
      display.println("Press UP to menu");
      break;
    case MODE_WEATHER:
      display.println("WEATHER");
      display.println(cities[cityIndex]);
      display.println("Press SELECT to next city");
      break;
    case MODE_XSMB:
      display.println("XSMB (Mi\\u00E8n Bac)");
      display.println("Press SELECT to fetch");
      break;
    case MODE_NEWS:
      display.println("NEWS - VnExpress");
      display.println("Press SELECT to fetch");
      break;
  }
  display.display();
}

void getWeather(const char* qcity){
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); }
  HTTPClient http;
  String url = String("http://api.openweathermap.org/data/2.5/weather?q=") + qcity + "&appid=" + OPENWEATHER_API_KEY + "&units=metric&lang=vi";
  http.begin(url);
  int code = http.GET();
  if (code == HTTP_CODE_OK){
    String payload = http.getString();
    DynamicJsonDocument doc(2048);
    DeserializationError err = deserializeJson(doc, payload);
    if (!err){
      float temp = doc["main"]["temp"] | 0.0;
      const char* desc = doc["weather"][0]["description"] | "";
      display.clearDisplay();
      display.setCursor(0,0);
      display.println(qcity);
      display.printf("%.1f C\n", temp);
      display.println(desc);
      display.display();
    } else {
      Serial.println("JSON parse error");
    }
  } else {
    Serial.printf("Weather HTTP fail: %d\n", code);
  }
  http.end();
}

void getXsmb(){
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); }
  HTTPClient http;
  http.begin(XSMB_API);
  int code = http.GET();
  if (code == HTTP_CODE_OK){
    String payload = http.getString();
    // Expect JSON with fields like DB, G1, G2... depending on API
    display.clearDisplay();
    display.setCursor(0,0);
    display.println("XSMB:");
    if (payload.length() > 120) payload = payload.substring(0,120);
    display.println(payload);
    display.display();
  } else {
    Serial.printf("XSMB fail: %d\n", code);
  }
  http.end();
}

void getNews(){
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); }
  HTTPClient http;
  http.begin(VNEXPRESS_RSS);
  int code = http.GET();
  if (code == HTTP_CODE_OK){
    String xml = http.getString();
    int it = xml.indexOf("<item>");
    if (it >= 0){
      int t1 = xml.indexOf("<title>", it);
      int t2 = xml.indexOf("</title>", t1);
      if (t1 >=0 && t2 > t1){
        String title = xml.substring(t1+7, t2);
        display.clearDisplay();
        display.setCursor(0,0);
        display.println("Top news:");
        display.println(title);
        display.display();
      }
    }
  } else {
    Serial.printf("RSS fail: %d\n", code);
  }
  http.end();
}

void loop(){
  // Read buttons (simple debouncing omitted for brevity)
  bool upPressed = digitalRead(BTN_UP) == LOW;
  bool selPressed = digitalRead(BTN_SELECT) == LOW;

  if (upPressed){
    // cycle modes
    if (mode == MODE_HOME) mode = MODE_WEATHER;
    else if (mode == MODE_WEATHER) mode = MODE_XSMB;
    else if (mode == MODE_XSMB) mode = MODE_NEWS;
    else mode = MODE_HOME;
    delay(300);
  }
  if (selPressed){
    // action inside mode
    if (mode == MODE_WEATHER){
      cityIndex = (cityIndex + 1) % CITY_COUNT;
      getWeather(cities[cityIndex]);
    } else if (mode == MODE_XSMB){
      getXsmb();
    } else if (mode == MODE_NEWS){
      getNews();
    }
    delay(300);
  }

  renderScreen();
  delay(100);
}
