DuyenKK PlatformIO project
--------------------------

Files:
- platformio.ini
- src/main.cpp

How to build:
1. Install PlatformIO (VSCode + PlatformIO extension) or use PlatformIO Core.
2. Open this folder as a PlatformIO project.
3. Edit WIFI_SSID, WIFI_PASS, OPENWEATHER_API_KEY in src/main.cpp
4. Build: `pio run`
5. Upload: `pio run -t upload` (ensure correct serial port and board connected)

Board: esp32-s3-devkitc-1 (change in platformio.ini if you have a different board)

Note:
- Libraries are declared in platformio.ini (lib_deps). PlatformIO will fetch them automatically.
- If you want a binary produced by CI, you can run `pio run -e esp32-s3-devkitc-1` on your machine or use the provided GitHub Actions workflow (not included here).