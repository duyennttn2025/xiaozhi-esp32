#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "ssd1306.h" // adjust to actual display driver header in repo

static const char *TAG = "custom_splash";

void app_main(void)
{
    ESP_LOGI(TAG, "Custom splash init");
    vTaskDelay(pdMS_TO_TICKS(400));

    // Initialize SSD1306 if the repo doesn't already
    ssd1306_init();
    ssd1306_clear_screen();
    ssd1306_draw_string(0, 0, "DuyenKK");
    ssd1306_draw_string(0, 24, "Firmware demo");
    ssd1306_refresh();
    vTaskDelay(pdMS_TO_TICKS(1500));
    vTaskDelete(NULL);
}
