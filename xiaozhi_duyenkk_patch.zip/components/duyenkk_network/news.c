#include "esp_log.h"
#include "esp_http_client.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "dkk_news";
const char* VNEXPRESS_RSS_URL = "https://vnexpress.net/rss/tin-moi-nhat.rss";

void duyenkk_news_fetch(void)
{
    esp_http_client_config_t config = { .url = VNEXPRESS_RSS_URL, .method = HTTP_METHOD_GET };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (esp_http_client_perform(client) == ESP_OK) {
        int status = esp_http_client_get_status_code(client);
        int len = esp_http_client_get_content_length(client);
        if (status == 200 && len > 0) {
            int toread = len > 20000 ? 20000 : len;
            char *buf = malloc(toread + 1);
            if (buf) {
                int r = esp_http_client_read_response(client, buf, toread);
                if (r > 0) {
                    buf[r] = 0;
                    char *it = strstr(buf, "<item>");
                    if (it) {
                        char *t1 = strstr(it, "<title>");
                        char *t2 = t1 ? strstr(t1, "</title>") : NULL;
                        if (t1 && t2 && t2 > t1) {
                            int len = (int)(t2 - (t1 + 7));
                            char *title = malloc(len + 1);
                            if (title) {
                                memcpy(title, t1 + 7, len);
                                title[len] = 0;
                                ESP_LOGI(TAG, "Top news: %s", title);
                                // TODO: display title via repo display API
                                free(title);
                            }
                        }
                    }
                }
                free(buf);
            }
        } else {
            ESP_LOGW(TAG, "RSS http status=%d len=%d", status, len);
        }
    } else {
        ESP_LOGE(TAG, "RSS fetch failed");
    }
    esp_http_client_cleanup(client);
}
