#include <string.h>
#include "esp_log.h"
#include "esp_http_client.h"
#include "cJSON.h"
#include <stdlib.h>

static const char *TAG = "dkk_weather";
// Recommend defining OPENWEATHER_API_KEY in sdkconfig or a header
#ifndef OPENWEATHER_API_KEY
#define OPENWEATHER_API_KEY "YOUR_OPENWEATHER_KEY"
#endif

void duyenkk_weather_fetch(const char* city)
{
    if (city == NULL) return;
    char url[512];
    snprintf(url, sizeof(url),
        "http://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric&lang=vi",
        city, OPENWEATHER_API_KEY);

    esp_http_client_config_t config = { .url = url, .method = HTTP_METHOD_GET };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    esp_err_t err = esp_http_client_perform(client);
    if (err == ESP_OK) {
        int status = esp_http_client_get_status_code(client);
        int len = esp_http_client_get_content_length(client);
        if (status == 200 && len > 0) {
            char *buf = malloc(len + 1);
            if (buf) {
                int r = esp_http_client_read_response(client, buf, len);
                if (r > 0) {
                    buf[r] = 0;
                    cJSON *root = cJSON_Parse(buf);
                    if (root) {
                        cJSON *main = cJSON_GetObjectItem(root, "main");
                        cJSON *weather = cJSON_GetArrayItem(cJSON_GetObjectItem(root, "weather"),0);
                        if (main && weather) {
                            double temp = cJSON_GetObjectItem(main, "temp")->valuedouble;
                            const char *desc = cJSON_GetObjectItem(weather, "description")->valuestring;
                            ESP_LOGI(TAG, "City=%s temp=%.1f desc=%s", city, temp, desc);
                            // TODO: display via repo's display API
                        }
                        cJSON_Delete(root);
                    }
                }
                free(buf);
            }
        } else {
            ESP_LOGW(TAG, "HTTP status=%d len=%d", status, len);
        }
    } else {
        ESP_LOGE(TAG, "HTTP request failed: %s", esp_err_to_name(err));
    }
    esp_http_client_cleanup(client);
}
