#include "esp_log.h"
#include "esp_http_client.h"
#include "cJSON.h"
#include <stdlib.h>

static const char *TAG = "dkk_xsmb";
const char* XSMB_API_URL = "https://api-xsmb.cyclic.app/api/v1";

void duyenkk_xsmb_fetch(void)
{
    esp_http_client_config_t config = { .url = XSMB_API_URL, .method = HTTP_METHOD_GET };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (esp_http_client_perform(client) == ESP_OK) {
        int status = esp_http_client_get_status_code(client);
        int len = esp_http_client_get_content_length(client);
        if (status == 200 && len > 0) {
            int toread = len > 20000 ? 20000 : len;
            char *buf = malloc(toread + 1);
            if (buf) {
                int r = esp_http_client_read_response(client, buf, toread);
                if (r > 0) {
                    buf[r] = 0;
                    ESP_LOGI(TAG, "XSMB JSON: %.200s", buf);
                    // TODO: parse JSON and update display
                }
                free(buf);
            }
        } else {
            ESP_LOGW(TAG, "XSMB http status=%d len=%d", status, len);
        }
    } else {
        ESP_LOGE(TAG, "XSMB request failed");
    }
    esp_http_client_cleanup(client);
}
