Patch bundle for Xiaozhi repo - DuyenKK additions

Files added:
- components/custom_splash/CMakeLists.txt
- components/custom_splash/main.c
- components/duyenkk_network/CMakeLists.txt
- components/duyenkk_network/weather.c
- components/duyenkk_network/xsmb.c
- components/duyenkk_network/news.c
- .github/workflows/build.yml

Instructions:
1. Download this bundle and copy the 'components' folder into the root of your xiaozhi-esp32 repo (merge with existing components).
2. Add the workflow file to your repo and push to GitHub. The workflow will build the firmware and upload build/ as an artifact.
3. Edit weather.c to set OPENWEATHER_API_KEY or set it via sdkconfig/header.
4. Adjust display function calls (TODO spots) to match xiaozhi display APIs if necessary.
5. Commit and push. Check Actions -> build -> download artifacts for the firmware binaries.
